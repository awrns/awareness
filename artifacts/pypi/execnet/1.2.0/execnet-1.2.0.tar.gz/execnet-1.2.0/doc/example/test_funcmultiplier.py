
def test_function():
    import funcmultiplier
