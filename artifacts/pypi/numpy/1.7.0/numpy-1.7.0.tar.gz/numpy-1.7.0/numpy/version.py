
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.7.0'
version = '1.7.0'
full_version = '1.7.0'
git_revision = '0c5a166183764aeb3fd1fba799caea489f20682f'
release = True

if not release:
    version = full_version
