Authors
=======

* Marc Schlaich - http://www.schlamar.org
* Rick van Hattem - http://wol.ph
* Buck Evan - https://github.com/bukzor
* Eric Larson - http://larsoner.com
* Marc Abramowitz - http://marc-abramowitz.com
* Thomas Kluyver - https://github.com/takluyver
* Guillaume Ayoub - http://www.yabz.fr
* Federico Ceratto - http://firelet.net
* Josh Kalderimis - http://blog.cookiestack.com
* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Christian Ledermann - https://github.com/cleder
* Alec Nikolas Reiter - https://github.com/justanr
* Patrick Lannigan - https://github.com/plannigan
* David Szotten - https://github.com/davidszotten
* Michael Elovskikh - https://github.com/wronglink
* Saurabh Kumar - https://github.com/theskumar
* Michael Elovskikh - https://github.com/wronglink
* Daniel Hahler - https://daniel.hahler.de
* Florian Bruhin - http://www.the-compiler.org
* Zoltan Kozma - https://github.com/kozmaz87
* Francis Niu - https://flniu.github.io
* Jannis Leidel - https://github.com/jezdez
