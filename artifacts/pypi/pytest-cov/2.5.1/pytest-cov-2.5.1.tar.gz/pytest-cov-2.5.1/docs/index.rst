Welcome to pytest-cov's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   contributing
   releasing
   authors
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

