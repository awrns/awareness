============
Installation
============

At the command line::

    pip install pytest-cov
