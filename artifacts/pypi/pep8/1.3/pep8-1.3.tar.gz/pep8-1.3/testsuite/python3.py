#!/usr/bin/env python3


# Annotated function (Issue #29)
def foo(x: int) -> int:
    return x + 1
