pytest development status
================================

https://travis-ci.org/pytest-dev/pytest

