
def test_upper():
    assert 'foo'.upper() == 'FOO'

def test_lower():
    assert 'FOO'.lower() == 'foo'