
# run this with $ pytest --collect-only test_collectonly.py
#
def test_function():
    pass

class TestClass(object):
    def test_method(self):
        pass
    def test_anothermethod(self):
        pass
