py.test is a simple and popular testing tool for Python.

See http://pytest.org for more documentation.

