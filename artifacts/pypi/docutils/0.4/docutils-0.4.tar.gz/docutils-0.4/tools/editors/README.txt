======================================
 Editor Support for reStructuredText_
======================================

:Date: $Date: 2005-06-28 15:11:20 +0200 (Tue, 28 Jun 2005) $

The files in this directory contain support code for reStructuredText
editing for the following editors:

* `Emacs <emacs>`__

External links:

* `reStructuredText syntax highlighting mode for vim
  <http://www.vim.org/scripts/script.php?script_id=973>`__

* `rst mode <http://jedmodes.sf.net/mode/rst/>`__ for the `JED`_
  programmers editor

Additions are welcome.

.. _reStructuredText: http://docutils.sf.net/rst.html
.. _JED: http://www.jedsoft.org/jed/
