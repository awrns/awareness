*************
Byte-swapping
*************

.. automodule:: numpy.doc.byteswapping
