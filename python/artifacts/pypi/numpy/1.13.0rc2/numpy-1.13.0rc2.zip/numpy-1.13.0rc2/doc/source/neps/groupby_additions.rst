.. include:: ../../neps/groupby_additions.rst
