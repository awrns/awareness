
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.13.0rc2'
version = '1.13.0rc2'
full_version = '1.13.0rc2'
git_revision = '59aec750c677b348dce102bc6fa1e6f9395362b8'
release = True

if not release:
    version = full_version
