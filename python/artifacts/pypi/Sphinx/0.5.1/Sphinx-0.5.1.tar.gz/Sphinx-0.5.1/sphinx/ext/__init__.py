# -*- coding: utf-8 -*-
"""
    sphinx.ext
    ~~~~~~~~~~

    Contains Sphinx features not activated by default.

    :copyright: 2008 by Georg Brandl.
    :license: BSD.
"""
